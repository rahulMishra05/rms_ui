import React from 'react'
import './resumeBuilder.css'

function MainSection() {
	return (
		<main className="mainsection">
			<h1>MainSection</h1>
		</main>
	)
}

export default MainSection