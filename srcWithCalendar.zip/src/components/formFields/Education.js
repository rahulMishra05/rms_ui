import React from 'react'

function Education() {
	return (
		<div>
			
		</div>
	)
}

export default Education